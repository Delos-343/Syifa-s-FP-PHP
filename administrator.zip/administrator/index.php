
<?php
?>

<html>
	<head>
		<title> Admin Privileges </title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    
		<link rel="stylesheet" type="text/css" href="css/index_style.css" />
	</head>
	<body>
    <body>
    <header class="nav center">
      <h1> Welcome, Administrator </h1>
    </header>
    <section class="main">
      <div class="box">
          <div class="second-box">
            <h2> &nbsp; Administrator Menu </h2>
            <div class="nav-link center">
              <a href="#"><h3> Manage Administrators</h3></a>
              <div class="line"></div>
              <a href="#"><h3> Manage Librarians</h3></a>
              <div class="line"></div>
              <a href="#"><h3> Manage Users</h3></a>
              <div class="line"></div>
              <a href="#"><h3> View Transactions</h3></a>
              <div class="line"></div>
              <a href="#"><h3> Manage Library Items</h3></a>
              <div class="line"></div>
            </div>
         </div>
        </div>
    </section>
	</body>
</html>